
console.log("Phantom Engine Loaded — Version 1.0");
